#include "server.h"

int main(void)
{
	server_init();
	runloop();
	return 0;
}
